
export class Fixture {
    constructor(
        public date: string,
        public match_id: string,
        public match_name: string,
        public team_a: string,
        public team_b: string,
        public match_type: string,
        public stadium: string,
        public local_time: string
    ) {  }
}