module.exports = {
    //DB: 'mongodb://localhost:27017/skillsports'
    DB: 'mongodb://gallop_kkl:gallop_kkl_123@ds261072.mlab.com:61072/galloptest'
 };